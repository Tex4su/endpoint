const express = require('express');
const app = express();
const hello = require('./routes/hello');
const hitung = require('./routes/hitung');
const igstalker = require('./routes/igstalker');
const orderkuota = require('./routes/orderkuota');

app.use(express.json());

app.use('/api', hello);
app.use('/api', hitung);
app.use('/api', igstalker);
app.use('/api', orderkuota);

app.get('/', (req, res) => {
    res.json({ status: "ok", message: "GhostX Clone API Node.js" });
});

app.listen(3000, () => {
    console.log('API running on http://localhost:3000');
});