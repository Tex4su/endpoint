const express = require('express');
const router = express.Router();

router.get('/hello', (req, res) => {
    const name = req.query.name || "World";
    res.json({ message: `Hello ${name}!` });
});

module.exports = router;