const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');

const orders = {};

router.post('/order-kuota', (req, res) => {
    const { provider, nomor, paket } = req.body;
    if (!provider || !nomor || !paket) {
        return res.status(400).json({ error: "provider, nomor, dan paket wajib diisi" });
    }

    const order_id = uuidv4();
    const payment_link = `https://fake-payment.test/pay/${order_id}`;

    orders[order_id] = {
        provider, nomor, paket,
        status: "pending",
        payment_link
    };

    res.json({ order_id, payment_link, status: "pending" });
});

router.get('/order-status', (req, res) => {
    const order_id = req.query.order_id;
    if (!order_id || !orders[order_id]) {
        return res.status(404).json({ error: "Order ID tidak ditemukan" });
    }

    res.json({ order_id, status: orders[order_id].status });
});

module.exports = router;