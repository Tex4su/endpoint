const express = require('express');
const router = express.Router();

router.get('/igstalker', (req, res) => {
    const username = req.query.username;
    if (!username) return res.json({ error: "Parameter username wajib diisi" });

    const data = {
        username: username,
        name: "Contoh Nama",
        followers: 1200,
        following: 300,
        bio: "Ini bio palsu",
        profile_pic: "https://i.imgur.com/profile.jpg"
    };

    res.json({ status: "success", data });
});

module.exports = router;