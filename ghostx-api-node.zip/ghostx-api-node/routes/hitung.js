const express = require('express');
const router = express.Router();

router.get('/hitung', (req, res) => {
    const a = parseInt(req.query.a);
    const b = parseInt(req.query.b);
    if (isNaN(a) || isNaN(b)) {
        return res.json({ error: "Masukkan angka yang valid" });
    }
    res.json({ hasil: a + b });
});

module.exports = router;